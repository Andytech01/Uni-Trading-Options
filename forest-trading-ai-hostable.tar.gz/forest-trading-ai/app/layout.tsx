import './globals.css';
export const metadata={title:'Forest Trading AI',description:'AI-powered market intelligence for stocks and crypto'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
