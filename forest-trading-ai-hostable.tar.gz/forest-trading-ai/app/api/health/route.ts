import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    success: true,
    data: { status: 'ok', service: 'forest-trading-ai', environment: process.env.NODE_ENV },
    error: null,
    timestamp: new Date().toISOString(),
  });
}
