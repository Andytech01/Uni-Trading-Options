import { NextResponse } from 'next/server';
import { getMarketOverview } from '@/lib/market-data';

export async function GET() {
  const data = await getMarketOverview();
  return NextResponse.json({ success: true, data, error: null, timestamp: new Date().toISOString() }, { headers: { 'Cache-Control': 's-maxage=30, stale-while-revalidate=60' } });
}
