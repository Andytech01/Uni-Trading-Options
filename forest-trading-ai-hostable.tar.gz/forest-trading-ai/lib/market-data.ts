export type MarketQuote = {
  symbol: string;
  name: string;
  price: number | null;
  changePct: number | null;
  high: number | null;
  low: number | null;
  volume: number | null;
  source: string;
  asOf: string | null;
  available: boolean;
};

const symbols = [
  { symbol: 'SPY', name: 'S&P 500' },
  { symbol: 'QQQ', name: 'NASDAQ 100' },
  { symbol: 'DIA', name: 'Dow Jones' },
];

async function finnhubQuote(symbol: string): Promise<MarketQuote> {
  const key = process.env.MARKET_DATA_API_KEY;
  if (!key) return unavailable(symbol);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${encodeURIComponent(key)}`, { signal: controller.signal, next: { revalidate: 30 } });
    if (!response.ok) throw new Error('market provider error');
    const q = await response.json();
    if (typeof q.c !== 'number') return unavailable(symbol);
    return { symbol, name: symbols.find(s => s.symbol === symbol)?.name ?? symbol, price: q.c, changePct: q.dp ?? null, high: q.h ?? null, low: q.l ?? null, volume: null, source: 'Finnhub', asOf: q.t ? new Date(q.t * 1000).toISOString() : null, available: true };
  } catch { return unavailable(symbol); }
  finally { clearTimeout(timeout); }
}

function unavailable(symbol: string): MarketQuote {
  return { symbol, name: symbols.find(s => s.symbol === symbol)?.name ?? symbol, price: null, changePct: null, high: null, low: null, volume: null, source: 'Not configured', asOf: null, available: false };
}

export async function getMarketOverview() {
  return Promise.all(symbols.map(s => finnhubQuote(s.symbol)));
}
