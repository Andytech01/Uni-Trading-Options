#!/bin/sh
set -e
if [ -n "${DATABASE_URL:-}" ]; then
  npx prisma migrate deploy || echo "Database migrations not applied; run them during first deployment."
fi
exec node server.js
